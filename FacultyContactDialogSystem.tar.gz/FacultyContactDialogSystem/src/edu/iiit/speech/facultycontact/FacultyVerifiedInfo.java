package edu.iiit.speech.facultycontact;

public class FacultyVerifiedInfo {
	private String facultyID;
	private String InfoTypeID;
	/**
	 * @return the facultyID
	 */
	public String getFacultyID() {
		return facultyID;
	}
	/**
	 * @param facultyID the facultyID to set
	 */
	public void setFacultyID(String facultyID) {
		this.facultyID = facultyID;
	}
	/**
	 * @return the infoTypeID
	 */
	public String getInfoTypeID() {
		return InfoTypeID;
	}
	/**
	 * @param infoTypeID the infoTypeID to set
	 */
	public void setInfoTypeID(String infoTypeID) {
		InfoTypeID = infoTypeID;
	}
}
